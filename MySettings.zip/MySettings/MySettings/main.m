//
//  main.m
//  MySettings
//
//  Created by Heather  on 4/5/13.
//  Copyright (c) 2013 Heather Pruitt. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "rvcAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([rvcAppDelegate class]));
    }
}
