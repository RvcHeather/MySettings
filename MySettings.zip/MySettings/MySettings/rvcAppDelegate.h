//
//  rvcAppDelegate.h
//  MySettings
//
//  Created by Heather  on 4/5/13.
//  Copyright (c) 2013 Heather Pruitt. All rights reserved.
//

#import <UIKit/UIKit.h>

@class rvcViewController;

@interface rvcAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) rvcViewController *viewController;

@end
